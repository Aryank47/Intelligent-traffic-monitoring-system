# object detection  > 2025-04-09 1:16pm
https://universe.roboflow.com/chandra-pm7ym/object-detection-j7oij

Provided by a Roboflow user
License: Public Domain

